Instructions

1) put train_features.csv, test_features.csv and train_labels in data/
2) run code/generate_datasets.py to build new clean and processed datasets
3) run code/find_features to build data/usefulness_matrix_t1_sum.csv and data/usefulness_matrix_t3_sum.csv
	This step takes longer than the actual training, so the output has already been included in the submission.
4) run code/main.py

The file best_kernel has been hand written.
